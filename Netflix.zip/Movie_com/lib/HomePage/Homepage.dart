import 'package:flip_card/flip_card.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:movie_com/Api/Cat.withLang/Category.dart';
import 'package:movie_com/Api/Cat.withLang/SubCategory.dart';
import 'package:movie_com/Api/Movie_1/Detail.dart';
import 'package:movie_com/Api/Movie_1/MovieApi.dart';
import 'package:movie_com/HomePage/BottomBar.dart';
import 'package:movie_com/HomePage/ImagePicker.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:movie_com/HomePage/Search.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter/material.dart' ;
import 'package:flutter_session_manager/flutter_session_manager.dart';

import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:image_picker/image_picker.dart';
import '../Api/Category/Category.dart';
import '../Api/Category/SubCategory.dart';
import '../Api/SLider/SLiderDetail.dart';
import '../Api/SLider/SliderPro.dart';
import '../Log&reg/Login.dart';

class homePage extends StatefulWidget {
  homePage({super.key,});

  @override
  State<homePage> createState() => _homePageState();
}

class _homePageState extends State<homePage> {
  Future<void> _launchUrl() async {
    if (!await launchUrl(_url)) {
      throw Exception('Could not launch $_url');
    }
  }
  final Uri _url = Uri.parse('https://www.jiocinema.com/tv-shows/asur/1/the-dead-can-talk/3216132');

  Future<void> clearSession() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove('username');
    prefs.remove('password');
    Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => login()));
  }
  Future<List<CatwithLang>> fetchDataLangCat(id) async{
    var url=Uri.parse("http://www.paji.store/webservice1.asmx/Language_Cat?"+id);
    final responce=await http.get(url);
    if(responce.statusCode==200){
      List listresponce=json.decode(responce.body);
      return listresponce.map((data) => CatwithLang.FromJson(data)).toList();
    }
    else{
      throw Exception('Unexpected error occured!');
    }


  }
  Future<List<SliderPro>> fetchDatapro(sid) async{
    var url=Uri.parse("http://www.paji.store/WebService1.asmx/Slider_");
    final responce=await http.get(url);
    if(responce.statusCode==200){
      List listresponce=json.decode(responce.body);
      return listresponce.map((data) => SliderPro.FromJson(data)).toList();
    }
    else{
      throw Exception('Unexpected error occured!');
    }


  }
  Future<List<Catid>> fetchData() async{
    var url=Uri.parse("http://www.paji.store/WebService1.asmx/Category?");
    final responce=await http.get(url);
    if(responce.statusCode==200){
      List listresponce=json.decode(responce.body);
      return listresponce.map((data) => Catid.FromJson(data)).toList();
    }
    else{
      throw Exception('Unexpected error occured!');
    }


  }
  Future<List<Movies>> fetchMovie_1() async{
    var url=Uri.parse("http://www.paji.store/webservice1.asmx/movies_1");
    final responce=await http.get(url);
    if(responce.statusCode==200){
      List listresponce=json.decode(responce.body);
      return listresponce.map((data) => Movies.FromJson(data)).toList();
    }
    else{
      throw Exception('Unexpected error occured!');
    }


  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      drawer: Drawer(
        width: 200,

        shape: BeveledRectangleBorder(borderRadius: BorderRadius.only(bottomRight: Radius.circular(95)),
            side: BorderSide(strokeAlign: Checkbox.width,
                color: Colors.grey,style:BorderStyle.solid)),
        child:  ListView(
          children: <Widget>[
            Container(height: 170,width: double.infinity,
              decoration: BoxDecoration(
                  image: DecorationImage(image: NetworkImage("https://help.nflxext.com/0af6ce3e-b27a-4722-a5f0-e32af4df3045_what_is_netflix_5_en.png"),fit: BoxFit.cover)
              ),
            ),

            new ListTile(

              title: new Text(
                'Themes',
                style: TextStyle(
                  fontSize: 16.0,
                  fontWeight: FontWeight.w600,
                ),
              ),
              onTap: () {
                Get.bottomSheet(
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Container(
                      margin: EdgeInsets.only(bottom: MediaQuery.of(context).size.height*.15,
                      left:MediaQuery.of(context).size.width*.25,
                      right: MediaQuery.of(context).size.width*.25),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.red.shade800,

                      ),
                      height: 60,
                      child: Wrap(
                          children:[
                            ListTile(

                              leading:IconButton(onPressed: (){
                                Get.changeTheme(ThemeData.light());
                              }, icon:  Icon(Icons.light_mode,size: 40,color: Colors.white,),) ,
                              trailing: IconButton(onPressed: (){
                                Get.changeTheme(ThemeData.dark());
                              }, icon: Icon(Icons.dark_mode_rounded,size: 40,color: Colors.white,),),


                            ),

                          ] ),
                    ),
                  ),
                );
              },
              leading: new Icon(
                Icons.mode_night_sharp,
                size: 26.0,
              ),
            ),
            new ListTile(
              title: new Text(
                'Notifications',
                style: TextStyle(
                  fontSize: 16.0,
                  fontWeight: FontWeight.w600,
                ),
              ),
              onTap: () {
                Get.to(
                    fullscreenDialog: true,transition:Transition.zoom,

                    Profile_Pic());
               },
              leading: new Icon(
                Icons.notifications,
                size: 26.0,
              ),
            ),
            new ListTile(
              title: new Text(
                'Favorites',
                style: TextStyle(
                  fontSize: 16.0,
                  fontWeight: FontWeight.w600,
                ),
              ),
              onTap: () {

                Navigator.pop(context);
              },
              leading: new Icon(
                Icons.favorite,
                size: 26.0,
              ),
            ),
            new Divider(
              color: Colors.black38,
            ),
            new ListTile(
              title: new Text(
                'About WelakaOne',
                style: TextStyle(
                  fontSize: 16.0,
                  fontWeight: FontWeight.w600,
                ),
              ),
              onTap: () {

              },
              leading: new Icon(
                Icons.info_outline,
                size: 26.0,
              ),
            ),
            new Divider(
            ),
            new ListTile(

              title: new Text(
                'Close Menu',
                style: TextStyle(
                  fontSize: 16.0,
                  fontWeight: FontWeight.w600,
                ),
              ),
              onTap: () {

                Navigator.pop(context);
              },
              leading: new Icon(
                Icons.close,
                size: 26.0,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(),
              child: Container(
                color: Colors.black12,
                child: ListTile(
                  onTap: () {
                    clearSession();

                  },
                  title:Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      new Text(
                        'Log Out',
                        style: TextStyle(
                          fontSize: 16.0,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      new Icon(
                        Icons.logout,
                        size: 26.0,
                      ),

                    ],),
                ),),)],),
      ),

      body:

      CustomScrollView(
          scrollDirection: Axis.vertical,
          slivers:[
            SliverAppBar(
              actions: [

                IconButton(onPressed: (){}, icon:
                Icon(Icons.new_releases_rounded,color: Colors.white,),
                ),
                IconButton(
                  onPressed: (){}, icon:  Icon(Icons.notifications,shadows: [BoxShadow(color: Colors.red.shade200,blurRadius: 6,offset: Offset(2,2))],color: Colors.white,),),
                IconButton(
                  onPressed: (){
                    Get.to(
                        fullscreenDialog: true,transition:Transition.fade,
                        search());

                    }, icon:Icon(Icons.search,color: Colors.white,shadows: [BoxShadow(color: Colors.red.shade200,blurRadius: 6,offset: Offset(2,2))]),
                ),

              ],iconTheme: IconThemeData(color: Colors.black,size: 27),
              expandedHeight: 170,
              backgroundColor: Colors.red[500],


              floating: false,
              pinned: true,
              flexibleSpace: FlexibleSpaceBar(
                background:Container(
                  decoration: BoxDecoration(
                      image: DecorationImage(fit: BoxFit.cover,
                        image: NetworkImage("https://i.pinimg.com/originals/a4/59/e5/a459e5a81b288ebecb680f7d08c633db.gif"),
                        colorFilter: new ColorFilter.mode(Colors.redAccent.withOpacity(1.0), BlendMode.softLight),
                      )
                  ),
                  child: Image.network("https://i.pinimg.com/originals/a4/59/e5/a459e5a81b288ebecb680f7d08c633db.gif",fit: BoxFit.cover,),



                ),
                title: Text("My Movies",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,shadows: [BoxShadow(color: Colors.black54,blurRadius: 10)]),),


              ),
            ),

            SliverToBoxAdapter(
              child: Column(
                children: [


                  Padding(
                    padding:  EdgeInsets.only(right: MediaQuery.of(context).size.width*.70,top: 10),
                    child: Text("Category",style: TextStyle(wordSpacing: 3,fontSize: 20,fontWeight: FontWeight.bold),),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 8.0,left: 10),
                    child: Container(
                      height: 150,
                      width: double.infinity,
                      child: FutureBuilder<List<Catid>>(
                          future: fetchData(),
                          builder: (context,abc){
                            if(abc.hasData){
                              return  ListView.builder(
                                  itemCount: abc.data!.length,

                                  scrollDirection: Axis.horizontal,
                                  itemBuilder: (BuildContext context,int len){
                                    return InkWell(
                                      onTap: (){
                                        Navigator.push(context,MaterialPageRoute(builder: (context){
                                          return Subcat(id:abc.data![len].id.toString()  );
                                        }));

                                      },
                                      child: Column(children: [

                                        Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Image.network(abc.data![len].img,height: 100,),
                                        ),
                                        Center(child:Text(abc.data![len].name))

                                      ],),
                                    );

                                  });
                            }
                            else if(abc.hasError){
                              return Text(abc.error.toString());

                            }
                            return  SpinKitChasingDots(
                              color: Colors.redAccent,
                            );
                          }

                      ),
                    ),
                  ),
                ],
              ),
            ),
            SliverToBoxAdapter(
              child: Column(
                children: [
                  Padding(
                    padding:  EdgeInsets.only(right: MediaQuery.of(context).size.width*.55),
                    child: Text("New Avaliable",style: TextStyle(wordSpacing: 3,fontSize: 20,fontWeight: FontWeight.bold),),
                  ),
                  Container(
                    height: 200,
                    width: MediaQuery.of(context).size.width,

                    child: FutureBuilder<List<SliderPro>>(
                        future: fetchDatapro(""+1.toString()),
                        builder: (context,abc){
                          if(abc.hasData){
                            return
                              CarouselSlider.builder(
                                itemCount: abc.data!.length,
                                itemBuilder: (BuildContext context, int index, int realIndex) {
                                  return InkWell(
                                      onTap: (){
                                        Get.to(
                                            fullscreenDialog: true,transition:Transition.fade,

                                            SliderDetail(id:abc.data![index].id,img: abc.data![index].img,Dis: abc.data![index].Dis,price: abc.data![index].price,name: abc.data![index].proname,));

                                      },
                                      child: Padding(
                                        padding: const EdgeInsets.only(right:3,left: 3),
                                        child: Image.network(abc.data![index].img, fit: BoxFit.cover),
                                      ));
                                },
                                options: CarouselOptions(
                                  height: 200,
                                  aspectRatio: 9 / 9,
                                  viewportFraction: .9,
                                  initialPage: 1,
                                  enableInfiniteScroll: true,
                                  autoPlay: true,
                                ),
                              );


                          }
                          else if(abc.hasError){
                            return Text(abc.error.toString());

                          }
                          return SpinKitChasingDots(
                            color: Colors.redAccent,
                          );
                        }

                    ),
                  ),


                  //Slider Container properties

                ],
              ),
            ),

            SliverToBoxAdapter(
              child:
              Padding(
                padding: const EdgeInsets.only(top: 8.0,left: 8),
                child: Container(
                  height: 170,
                  width: double.infinity,
                  child: Column(
                      children:[
                        Padding(
                          padding:  EdgeInsets.only(right: MediaQuery.of(context).size.width*.55),
                          child: Text("Drama Delights",style: TextStyle(wordSpacing: 3,fontSize: 20,fontWeight: FontWeight.bold),),
                        ),
                        Container(
                          height: 134,
                          child: FutureBuilder<List<Catid>>(
                              future: fetchData(),
                              builder: (context,abc){
                                if(abc.hasData){
                                  return  ListView.builder(
                                      itemCount: abc.data!.length,

                                      scrollDirection: Axis.horizontal,
                                      itemBuilder: (BuildContext context,int len){
                                        return InkWell(
                                          onTap: (){
                                            Navigator.push(context,MaterialPageRoute(builder: (context){
                                              return Subcat(id:abc.data![len].id.toString()  );
                                            }));

                                          },
                                          child: Column(children: [

                                            Padding(
                                              padding: const EdgeInsets.all(8.0),
                                              child: Image.network(abc.data![len].img,height: 100,),
                                            ),
                                            Center(child:Text(abc.data![len].name,))

                                          ],),
                                        );

                                      });
                                }
                                else if(abc.hasError){
                                  return Text(abc.error.toString());

                                }
                                return  SpinKitChasingDots(
                                  color: Colors.redAccent,
                                );
                              }

                          ),
                        ),
                      ]  ),
                ),
              ),

            ),
                   SliverToBoxAdapter(
                 child:  Column(
                   children: [
                     Padding(
                       padding:  EdgeInsets.only(right: MediaQuery.of(context).size.width*.40),
                       child: Text("Popular Movies Now",style: TextStyle(wordSpacing: 3,fontSize: 20,fontWeight: FontWeight.bold),),
                     ),
                     Padding(
                       padding: const EdgeInsets.only(top: 8.0,left: 8),
                       child: Container(
                         height: 130,


                         width: double.infinity,
                         child: FutureBuilder<List<Movies>>(
                             future: fetchMovie_1(),
                             builder: (context,abc){
                               if(abc.hasData){
                                 return  ListView.builder(
                                     itemCount: abc.data!.length,

                                     scrollDirection: Axis.horizontal,
                                     itemBuilder: (BuildContext context,int len){
                                       return InkWell(
                                         onTap: (){
                                           Get.to(
                                               fullscreenDialog: true,transition:Transition.leftToRightWithFade,
                                               SliderDetail(img:abc.data![len].img ,price: abc.data![len].price,Dis: abc.data![len].Dis,name: abc.data![len].proname,id: abc.data![len].id,));
                                         },
                                         child: Column(children: [
                                           Padding(
                                             padding: const EdgeInsets.all(8.0),
                                             child:   Container(
                                               height: 100,
                                               width: 140,
                                               decoration: BoxDecoration(
                                                   borderRadius: BorderRadius.circular(10),
                                                   boxShadow: [BoxShadow(
                                                       color: Colors.blueGrey,
                                                       blurRadius: 5
                                                   )],
                                                   image: DecorationImage(image: NetworkImage(abc.data![len].img),fit: BoxFit.cover)
                                               ),

                                             ),
                                           )
                                         ],),
                                       );

                                     });
                               }
                               else if(abc.hasError){
                                 return Text(abc.error.toString());

                               }
                               return SpinKitChasingDots(
                                 color: Colors.redAccent,
                               );
                             }

                         ),
                       ),
                     ),
                   ],
                 ),),
             SliverToBoxAdapter(
               child:
               Padding(
                 padding: const EdgeInsets.only(bottom: 8.0),
                 child: InkWell(
                 focusColor: Colors.blue,
                     onTap: _launchUrl,

                     child: Image.network("https://st1.latestly.com/wp-content/uploads/2023/05/157-1.jpg",fit: BoxFit.cover,)),
               ),
             ),
             SliverToBoxAdapter(
                 child: Column(
                   children: [
                     Padding(
                       padding:  EdgeInsets.only(right: MediaQuery.of(context).size.width*.45),
                       child: Text("Popular Languages",style: TextStyle(wordSpacing: 3,fontSize: 20,fontWeight: FontWeight.bold),),
                     ),
                     Padding(
                       padding: const EdgeInsets.only(left: 8.0,right: 8,top: 4),
                       child: Container(
                         height: 120,
                         width: double.infinity,
                         child: FutureBuilder<List<CatwithLang>>(
                             future: fetchDataLangCat(""+1.toString()),
                             builder: (context,abc){
                               if(abc.hasData){
                                 return  ListView.builder(
                                     itemCount: abc.data!.length,
                                     scrollDirection: Axis.horizontal,
                                     itemBuilder: (BuildContext context,int len){
                                       return GestureDetector(
                                         onTap: (){
                                           Get.to(
                                               fullscreenDialog: true,transition:Transition.fade,
                                               LangSub(id:abc.data![len].id.toString(),name: abc.data![len].name.toString(),)
                                           );

                                         },
                                         child: Column(

                                           children: [

                                           Padding(
                                             padding: const EdgeInsets.only(left: 4.0,right: 4,top: 6),
                                             child:
                                             Container(
                                               height: 80,width: 150,
                                                 decoration: BoxDecoration(
                                                   border: Border.all(color: Colors.white,width: 0.10),
                                                   borderRadius: BorderRadius.circular(10),
                                                   image: DecorationImage(image: NetworkImage(abc.data![len].img,),fit: BoxFit.cover)
                                                 ),
                                             )
                                           ),


                                         ],),
                                       );

                                     });
                               }
                               else if(abc.hasError){
                                 return Text(abc.error.toString());

                               }
                               return SpinKitChasingDots(
                                 color: Colors.redAccent,
                               );
                             }

                         ),
                       ),
                     ),
                   ],
                 ),
               ),



          ]),



    );
  }
}
