import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:get/get.dart';
import 'package:movie_com/Api/Cat.withLang/SubCategory.dart';

class CatwithLang{
  final int id;
  final String name;
  final String img;
  CatwithLang({required this.id,required this.name,required this.img});
  factory CatwithLang.FromJson(Map<String,dynamic>json){
    return CatwithLang(id: json['id'],name: json['Name'],img: "http://www.paji.store/upload/"+json['Img']);

  }
}
class LangCat extends StatefulWidget {
  const LangCat({super.key});

  @override
  State<LangCat> createState() => _LangCatState();
}

class _LangCatState extends State<LangCat> {
  Future<List<CatwithLang>> fetchData(id) async{
    var url=Uri.parse("http://www.paji.store/webservice1.asmx/Language_Cat?"+id);
    final responce=await http.get(url);
    if(responce.statusCode==200){
      List listresponce=json.decode(responce.body);
      return listresponce.map((data) => CatwithLang.FromJson(data)).toList();
    }
    else{
      throw Exception('Unexpected error occured!');
    }


  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(title: Text("Category"),),
      body: Container(

        width: double.infinity,
        child: FutureBuilder<List<CatwithLang>>(
            future: fetchData(""+1.toString()),
            builder: (context,abc){
              if(abc.hasData){
                return  ListView.builder(
                    itemCount: abc.data!.length,
                    scrollDirection: Axis.horizontal,
                    itemBuilder: (BuildContext context,int len){
                      return GestureDetector(
                        onTap: (){
                          Get.to(
                              fullscreenDialog: true,transition:Transition.fade,
                              LangSub(id:abc.data![len].id.toString(),name: abc.data![len].name.toString(),)
);

                        },
                        child: Column(children: [

                          CircleAvatar(
                            radius: 50,
                            backgroundImage: NetworkImage(abc.data![len].img,),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              children: [
                                Center(child:Text(abc.data![len].name)),
                                Text(abc.data![len].id.toString())
                              ],
                            ),
                          )

                        ],),
                      );

                    });
              }
              else if(abc.hasError){
                return Text(abc.error.toString());

              }
              return  SpinKitRotatingCircle(
                color: Colors.redAccent,
                size: 50.0,
              );
            }

        ),
      ),
    );
  }
}
