import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:get/get.dart';
import 'package:movie_com/Api/Cat.withLang/Details.dart';

class LangSubCat{
  final String sid;
  final String name;
  final String img;
  LangSubCat({required this.sid,required this.name,required this.img});
  factory LangSubCat.FromJson(Map<String,dynamic>json){
    return LangSubCat(sid: json['sid'].toString(),name: json['subname'],img: "http://www.paji.store/upload/"+json['subimage']);

  }
}
class LangSub extends StatefulWidget {
  final String id;
  final String name;

  const LangSub({super.key, required this.id, required this.name,});

  @override
  State<LangSub> createState() => _LangSubState();
}

class _LangSubState extends State<LangSub> {
  Future<List<LangSubCat>>fetchData(id) async{
    var url=Uri.parse("http://www.paji.store/webservice1.asmx/Language_SubCat?id="+id);
    final responce=await http.get(url);
    if(responce.statusCode==200){

      List listresponce=json.decode(responce.body);

      return listresponce.map((data) => LangSubCat.FromJson(data)).toList();
    }
    else{
      throw Exception('Unexpected error occured!');
    }


  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: SingleChildScrollView(
scrollDirection: Axis.vertical,
        child:  Column(
              children:[

                Padding(
                  padding:  EdgeInsets.only(left: 18.0,top: 50),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(widget.name,style: TextStyle(fontSize: 30),),
                    ],
                  ),
                ),
                Container(

                  height: MediaQuery.of(context).size.height*.94,

                  child: FutureBuilder<List<LangSubCat>>(
                      future: fetchData(widget.id),
                      builder: (context,abc){
                        if(abc.hasData){
                          return
                          GridView.builder(
                              itemCount:abc.data!.length ,
                              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                              mainAxisSpacing: 1,crossAxisSpacing: 1,
                              crossAxisCount: 3), itemBuilder: (context,ind){
                            return   Padding(
                                padding: const EdgeInsets.only(left: 4.0,right: 4,top: 6),
                                child:
                                GestureDetector(
                                  onTap: (){
                                    Get.to(
                                        fullscreenDialog: true,transition:Transition.zoom,

                                        LanDetails(name: abc.data![ind].name, img: abc.data![ind].img,));
                                  },
                                  child: Container(

                                    decoration: BoxDecoration(

                                        border: Border.all(color: Colors.white,width: 0.10),
                                        borderRadius: BorderRadius.circular(5),

                                        image: DecorationImage(image: NetworkImage(abc.data![ind].img,),fit: BoxFit.cover)

                                    ),

                                  ),
                                ),
                            );
                          });

                        }
                        else if(abc.hasError){
                          return Text(abc.error.toString());

                        }
                        return  Icon(Icons.circle_outlined);
                      }

                  ),
                ),
              ]  ),
        ),

    );
  }
}
