import 'dart:convert';

import 'package:flip_card/flip_card.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:movie_com/Api/Movie_1/MovieApi.dart';
import 'package:http/http.dart' as http;
import 'package:movie_com/HomePage/Tappage.dart';

class LanDetails extends StatefulWidget {
  final String name;
  final String img;
  const LanDetails({super.key, required this.name, required this.img,});

  @override
  State<LanDetails> createState() => _LanDetailsState();
}

class _LanDetailsState extends State<LanDetails> {
  Future<List<Movies>> fetchData() async{
    var url=Uri.parse("http://www.paji.store/webservice1.asmx/movies_1");
    final responce=await http.get(url);
    if(responce.statusCode==200){
      List listresponce=json.decode(responce.body);
      return listresponce.map((data) => Movies.FromJson(data)).toList();
    }
    else{
      throw Exception('Unexpected error occured!');
    }


  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Container(


            child: Column(children: [
              Padding(
                padding:  EdgeInsets.only(left: 8.0,top: 30),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Details",style: TextStyle(fontSize: 30),),
/*
                  IconButton(onPressed: (){}, icon: Icon(Icons.search,color: Colors.white,))
*/
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Stack(
                      children: [
                        Container(
                          margin: EdgeInsets.all(10),
                          alignment: Alignment.topRight,
                          height:MediaQuery.of(context).size.height*.30,width:MediaQuery.of(context).size.width*.94,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              boxShadow: [BoxShadow(color: Colors.white70,blurRadius: 7)],
                              image: DecorationImage(image: NetworkImage(widget.img),fit: BoxFit.cover)
                          ),

                        ),

                        Positioned (
                          top: MediaQuery.of(context).size.height*.25,
                          left: MediaQuery.of(context).size.width*.80,
                          child: FlipCard(
                            direction: FlipDirection.VERTICAL, // You can change the direction here
                            flipOnTouch: true,
                            front:Container(
                                height: 40,width: 40,
                                decoration: BoxDecoration(

                                    color: Colors.white,
                                    borderRadius: BorderRadius.all(Radius.circular(10))),
                                child: Icon( Icons.favorite_border,color: Colors.black,size: 30,)),
                            back: Container(

                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.all(Radius.circular(10))),

                                height: 40,width: 40,
                                child: Icon( Icons.favorite,color: Colors.redAccent,size: 30, )),
                            onFlip: () {
                              setState(() {

                              });
                            },
                          ),
                        ),
                      ],
                    ),


                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 18.0,right: 15),
                child: Row(

                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(widget.name,),


                  ],
                ),
              ),
              SizedBox(height: 5,),


              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(children: [
                  Divider(thickness: 1),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [

                      FlipCard(
                        direction: FlipDirection.VERTICAL, // You can change the direction here
                        flipOnTouch: true,
                        front:Icon( Icons.add,size: 30,),
                        back: Icon( Icons.favorite,color: Colors.redAccent,size: 30, ),
                        onFlip: () {
                          setState(() {

                          });
                        },
                      ),
                      FlipCard(
                        direction: FlipDirection.VERTICAL, // You can change the direction here
                        flipOnTouch: true,
                        front:Icon( Icons.download_sharp,size: 30,),
                        back: Icon( Icons.favorite,color: Colors.redAccent,size: 30, ),
                        onFlip: () {
                          setState(() {

                          });
                        },
                      ),
                      FlipCard(
                        direction: FlipDirection.VERTICAL, // You can change the direction here
                        flipOnTouch: true,
                        front:Icon( Icons.share,size: 30,),
                        back: Icon( Icons.favorite,color: Colors.redAccent,size: 30, ),
                        onFlip: () {
                          setState(() {

                          });
                        },
                      ),
                    ],
                  ),
                  Divider(thickness: 1),
                ],),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Container(

                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.white),
                        gradient: LinearGradient(colors: [
                          Colors.white,
                          Colors.red.shade100
                        ])

                    ),
                    height: 50,width: 100,
                    child: Center(child: Text('Watch Trailer',style: TextStyle(fontSize: 14,color: Colors.black87),),),
                  ),

                  Container(
                    height: 50,width: 100,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.white),
                        gradient: LinearGradient(colors: [
                          Colors.white,
                          Colors.red.shade100
                        ])
                    ),

                    child: Center(child: Text('Subscruption',style: TextStyle(fontSize: 14,color: Colors.black87),),),
                  ),
                ],
              ),
              Padding (
                padding: const EdgeInsets.only(top: 8.0,left: 8),
                child: Container(
                  height: 185,

                  width: double.infinity,
                  child: FutureBuilder<List<Movies>>(
                      future: fetchData(),
                      builder: (context,abc){
                        if(abc.hasData){
                          return  ListView.builder(
                              itemCount: abc.data!.length,

                              scrollDirection: Axis.horizontal,
                              itemBuilder: (BuildContext context,int len){
                                return InkWell(
                                  onTap: (){
                                    Get.to(
                                        fullscreenDialog: true,transition:Transition.leftToRightWithFade,
                                        Tap());
                                  },
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                    Padding(
                                      padding: const EdgeInsets.all(4.0),
                                      child:   Container(
                                        height: 160,
                                        width: 270,
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(10),
                                            boxShadow: [BoxShadow(
                                                color: Colors.blueGrey,
                                                blurRadius: 5
                                            )],
                                            image: DecorationImage(image: NetworkImage(abc.data![len].img),fit: BoxFit.cover)
                                        ),

                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(left: 4.0,right: 4),
                                      child: Text(abc.data![len].proname),
                                    ),
                                  ],),
                                );

                              });
                        }
                        else if(abc.hasError){
                          return Text(abc.error.toString());

                        }
                        return  Icon(Icons.circle_outlined);
                      }

                  ),
                ),
              ),
            ]),
          ),
        ));
  }
}
