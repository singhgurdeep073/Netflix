import 'dart:convert';

import 'package:flip_card/flip_card.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:movie_com/Api/Movie_1/MovieApi.dart';
import 'package:http/http.dart' as http;
import 'package:movie_com/HomePage/Tappage.dart';

class Movies1 extends StatefulWidget {
  final int id;
  final String name;
  final String img;
  final String price;
  final String Dis;
  const Movies1({super.key, required this.id, required this.name, required this.img, required this.price, required this.Dis,});

  @override
  State<Movies1> createState() => _Movies1State();
}

class _Movies1State extends State<Movies1> {
  Future<List<Movies>> fetchData() async{
    var url=Uri.parse("http://www.paji.store/webservice1.asmx/movies_1");
    final responce=await http.get(url);
    if(responce.statusCode==200){
      List listresponce=json.decode(responce.body);
      return listresponce.map((data) => Movies.FromJson(data)).toList();
    }
    else{
      throw Exception('Unexpected error occured!');
    }


  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Column(children: [

            Padding(
              padding:  EdgeInsets.only(left: 8.0,top: 30),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Details",style: TextStyle(fontSize: 30),),

                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Stack(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 4.0,right: 4),
                        child: Container(
                          alignment: Alignment.topRight,
                          height:MediaQuery.of(context).size.height*.35,width:MediaQuery.of(context).size.width*.97,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              boxShadow: [BoxShadow(color: Colors.white,blurRadius: 10)],
                              image: DecorationImage(image: NetworkImage(widget.img),fit: BoxFit.cover)
                          ),
                          child: Container(
                            decoration: BoxDecoration(
                              /*    color: Colors.redAccent.withOpacity(0.2),*/
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                      ),

                      Positioned (
                        top: MediaQuery.of(context).size.height*.28,
                        left:MediaQuery.of(context).size.width*.85 ,
                        child: FlipCard(
                          direction: FlipDirection.VERTICAL, // You can change the direction here
                          flipOnTouch: true,
                          front:Container(
                              height: 40,width: 40,
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.all(Radius.circular(10))),
                              child: Icon( Icons.favorite_border,color: Colors.black,size: 30,)),
                          back: Container(

                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.all(Radius.circular(10))),

                              height: 40,width: 40,
                              child: Icon( Icons.favorite,color: Colors.redAccent,size: 30, )),
                          onFlip: () {
                            setState(() {

                            });
                          },
                        ),
                      ),
                    ],
                  ),
                  /*Padding(
                    padding: const EdgeInsets.only(top: 200,left: 20),
                    child:     Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Total Prize "+widget.price,style: TextStyle(color: Colors.white,),),

                      ],
                    ),
                  ),*/

                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(18.0),
              child: Column(
                crossAxisAlignment:
                CrossAxisAlignment.start,
                children: [
                  Text(widget.name,style: TextStyle(color: Colors.white,fontSize: 25,/*shadows: [BoxShadow(color: Colors.red,blurRadius: 12)]*/),),
                  SizedBox(height: 5,),
                  Text(widget.Dis,style: TextStyle(color: Colors.grey),),
                ],
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(children: [
                Divider(thickness: 0.50,color: Colors.grey,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    FlipCard(
                      direction: FlipDirection.VERTICAL, // You can change the direction here
                      flipOnTouch: true,
                      front:IconButton(onPressed: (){
                      }, icon: Icon( Icons.lightbulb_circle_rounded,size: 30,),),
                      back:IconButton(onPressed: (){
                      }, icon: Icon(Icons.light_mode)),
                      onFlip: () {
                        setState(() {

                        });
                      },
                    ),
                    FlipCard(
                      direction: FlipDirection.VERTICAL, // You can change the direction here
                      flipOnTouch: true,
                      front:Icon( Icons.download_sharp,size: 30,),
                      back: Container(

                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.all(Radius.circular(10))),

                          height: 40,width: 40,
                          child: Icon( Icons.favorite,color: Colors.redAccent,size: 30, )),
                      onFlip: () {
                        setState(() {

                        });
                      },
                    ),
                    FlipCard(
                      direction: FlipDirection.VERTICAL, // You can change the direction here
                      flipOnTouch: true,
                      front:Icon( Icons.share,size: 30,),
                      back: Container(

                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.all(Radius.circular(10))),

                          height: 40,width: 40,
                          child: Icon( Icons.favorite,color: Colors.redAccent,size: 30, )),
                      onFlip: () {
                        setState(() {

                        });
                      },
                    ),
                  ],
                ),
                Divider(thickness: 0.50,color: Colors.grey,),
              ],),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Container(

                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.white),
                      gradient: LinearGradient(colors: [
                        Colors.white,
                        Colors.red.shade100
                      ])

                  ),
                  height: 50,width: 100,
                  child: Center(child: Text('Watch Trailer',style: TextStyle(fontSize: 14,color: Colors.black87),),),
                ),
                Container(

                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.white),
                      gradient: LinearGradient(colors: [
                        Colors.white,
                        Colors.red.shade100
                      ])

                  ),
                  height: 50,width: 100,
                  child: Center(child: Text("₹ "+widget.price,style: TextStyle(fontSize: 18,color: Colors.black87),),),
                ),
                Container(

                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.white),
                      gradient: LinearGradient(colors: [
                        Colors.white,
                        Colors.red.shade100
                      ])

                  ),
                  height: 50,width: 100,
                  child: Center(child: Text('Subscruption',style: TextStyle(fontSize: 14,color: Colors.black87),),),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(top: 8.0,left: 8),
              child: Container(
                height: 185,

                width: double.infinity,
                child: FutureBuilder<List<Movies>>(
                    future: fetchData(),
                    builder: (context,abc){
                      if(abc.hasData){
                        return  ListView.builder(
                            itemCount: abc.data!.length,

                            scrollDirection: Axis.horizontal,
                            itemBuilder: (BuildContext context,int len){
                              return InkWell(
                                onTap: (){
                                 Get.to(
                                 fullscreenDialog: true,transition:Transition.downToUp,

                                  Tap());
                                },
                                child: Column(children: [
                                Padding(
                                padding: const EdgeInsets.all(8.0),
                                 child:   Container(
                                   height: 160,
                                   width: 230,
                                decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                boxShadow: [BoxShadow(
                                color: Colors.blueGrey,
                                    blurRadius: 5
                                )],
                                  image: DecorationImage(image: NetworkImage(abc.data![len].img),fit: BoxFit.cover)),),)],),);});
                      }
                      else if(abc.hasError){
                        return Text(abc.error.toString());

                      }
                      return  Icon(Icons.circle_outlined);
                    }

                ),
              ),
            ),

          ]),
        ));
  }
}
