import 'dart:convert';
import 'package:movie_com/HomePage/Homepage.dart';
import 'package:movie_com/HomePage/ImagePicker.dart';
import 'package:movie_com/Log&reg/registation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:get/get.dart';
import '../HomePage/BottomBar.dart';
import 'ForgetPassword.dart';

class login extends StatefulWidget {

  login({Key? key}) : super(key: key);

  @override
  State<login> createState() => _loginState();
}

class _loginState extends State<login> {
  final _formKey = GlobalKey<FormState>();
  bool passwordVisible=false;


  final email = TextEditingController();
  final Pass = TextEditingController();
  /*void _login() {

     String _email = email.text;
     Navigator.pushReplacement(
       context,
       MaterialPageRoute(
         builder: (context) => Profile_Pic( ),
       ),
     );
   }*/
  @override
  void initState2() {
    super.initState();
    _loadSavedLoginData();
  }
  void _loadSavedLoginData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      email.text = prefs.getString('username') ?? '';
      Pass.text = prefs.getString('password') ?? '';
    });
  }
  void logind(e, p) async {
    try {
      // Send GET request to the API with query parameters
      final response = await http.get(
        Uri.parse('http://www.paji.store/WebService1.asmx/LoginApi?email=$e&password=$p'),
      );
      if(response.statusCode == 200) {
        List<dynamic> jsonList = json.decode(response.body);
        for (var item in jsonList) {
          String massage = item['msg'].toString();
          if(massage=="1")
          {
            SharedPreferences prefs = await SharedPreferences.getInstance();
            await prefs.setString('username',email.text);
            await prefs.setString('password',Pass.text);
            Get.to(bottom());
            Get.snackbar(
                colorText: Colors.white,
                backgroundColor: Colors.black12,
                "Login Success","✍🏻");
          }
          else{
            Get.snackbar(
              colorText: Colors.white,
                backgroundColor: Colors.black12,
                "Invalid Id or Password","Check Your Input Data");

          }
        }
      }
      else {
        print('Login failed');
      }}
    catch (e) {
      print('Error: $e');
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        body: Form(
          key: _formKey,
          child: Container(
            height: double.infinity,
            decoration: BoxDecoration(
                image: DecorationImage(image: NetworkImage("https://e0.pxfuel.com/wallpapers/653/834/desktop-wallpaper-red-border-amoled-black.jpg"),
                    fit: BoxFit.cover)
            ),
            child: Padding(
              padding: EdgeInsets.all(16.0),
              child: Column(
                  children: [
                    Image.asset("images/MyMovie.png",height: 250,),

                    TextFormField(
                      controller: email,
                      style: TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                        contentPadding: EdgeInsets.symmetric(vertical: 15.0),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                          borderRadius: BorderRadius.all(Radius.circular(10.0)),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.red),
                          borderRadius: BorderRadius.all(Radius.circular(10.0)),
                        ),
                        labelText: 'Gmail',
                        labelStyle: TextStyle(
                            fontSize: 13.0, color: Colors.white
                        ),
                        prefixIcon: Icon(
                          Icons.mail,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    SizedBox(height: 16.0),
                    TextFormField(
                      maxLength: 6,
                      controller: Pass,
                      style: TextStyle(color: Colors.white),
                      obscureText: passwordVisible,
                      decoration: InputDecoration(
                        contentPadding: EdgeInsets.symmetric(vertical: 15.0),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                          borderRadius: BorderRadius.all(Radius.circular(10.0)),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.red),
                          borderRadius: BorderRadius.all(Radius.circular(10.0)),
                        ),
                        labelText: "Password",
                        prefixIcon: Icon(
                          Icons.password_rounded,
                          color: Colors.white,
                        ),
                        labelStyle: TextStyle(
                            fontSize: 13.0, color: Colors.white
                        ),
                        suffixIcon: IconButton(
                          icon: Icon(passwordVisible
                              ? Icons.visibility_off_outlined
                              : Icons.visibility,color: Colors.white,),
                          onPressed: () {
                            setState(() {passwordVisible = !passwordVisible;},
                            );
                          },
                        ),

                      ),
                      keyboardType: TextInputType.visiblePassword,
                      textInputAction: TextInputAction.done,
                    ),

                    Padding(
                      padding: const EdgeInsets.only(left: 200.0),
                      child: GestureDetector(
                          onTap: (){
                            Get.to(Forget(),
                              fullscreenDialog: true,transition:Transition.zoom,
                            );
                            },
                          child: Text("Forget Password ",style: TextStyle(fontSize: 15,color: Colors.white),)),
                    ),
                    SizedBox(height: 16.0),
                    GestureDetector(
                      onTap:(){
                     /*    _login();*/
                        logind(email.text,Pass.text);
                      },
                      child:   Container(

                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: Colors.white),
                            gradient: LinearGradient(colors: [
                              Colors.white,
                              Colors.red.shade100
                            ])

                        ),
                        height: 50,width: 250,
                        child: Center(child: Text('Login',style: TextStyle(fontSize: 20,color: Colors.black87),),),
                      ),),
                    SizedBox(height: 10,),
                    GestureDetector(
                        onTap: (){
                          Get.to(
                              fullscreenDialog: true,transition:Transition.circularReveal,

                              Registation());
                        },
                        child: Text("Create Account ",style: TextStyle(fontSize: 15,color: Colors.white),)),

                  ]
              ),
            ),
          ),
        )        );      }
}




