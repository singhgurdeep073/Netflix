
import 'package:google_fonts/google_fonts.dart';
import 'package:movie_com/HomePage/Homepage.dart';
import 'package:movie_com/HomePage/Search.dart';
import 'package:movie_com/Log&reg/Login.dart';
import 'package:movie_com/TabBar_Pages/Tab_1.dart';
import 'package:movie_com/TabBar_Pages/Tab_2.dart';
import 'package:movie_com/TabBar_Pages/Tab_3.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CategoryPage extends StatefulWidget {
  const CategoryPage({super.key});

  @override
  State<CategoryPage> createState() => _CategoryPageState();
}

class _CategoryPageState extends State<CategoryPage> {
  final List<Tab> myTabs = <Tab>[
    Tab(icon:
    Text(
      'Hindi',
      style: GoogleFonts.aboreto(
        fontSize: 15,fontWeight: FontWeight.bold,

      ),
    )),
    Tab(icon:
    Text(
      'English',
      style: GoogleFonts.aboreto(
        fontSize: 15,fontWeight: FontWeight.bold,

      ),
    )),
    Tab(icon:
        Text(
          'Punjabi',
          style: GoogleFonts.aboreto(
            fontSize: 15,fontWeight: FontWeight.bold,

          ),
        )),
  ];

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
        length: myTabs.length,
        child: Scaffold(

          appBar: AppBar(
            title: Text("Movie with Language"),
            titleTextStyle: GoogleFonts.akayaKanadaka(fontSize: 25),
            backgroundColor: Colors.red,
            elevation: 0,
            bottom: TabBar(
                unselectedLabelColor: Colors.black,
                indicatorSize: TabBarIndicatorSize.tab,
                indicator: BoxDecoration(
                    gradient: LinearGradient(
                        colors: [Colors.white12, Colors.orangeAccent]),
                    borderRadius: BorderRadius.circular(7),
                    color: Colors.redAccent),
                tabs:myTabs
              ),
          ),
          body: TabBarView(children: [
            HindiMovies(),
            English(),
            Punjabi(),
          ]),
        )
    );
  }
}
