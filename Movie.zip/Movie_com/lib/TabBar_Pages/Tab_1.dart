import 'package:flutter/material.dart';

class HindiMovies extends StatefulWidget {
  const HindiMovies({super.key});

  @override
  State<HindiMovies> createState() => _HindiMoviesState();
}

class _HindiMoviesState extends State<HindiMovies> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurple.shade200,
      body: Center(child: Text("Tab 1")),
    );
  }
}
