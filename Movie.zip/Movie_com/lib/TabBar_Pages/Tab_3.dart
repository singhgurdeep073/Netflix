import 'package:flutter/material.dart';

class Punjabi extends StatefulWidget {
  const Punjabi({super.key});

  @override
  State<Punjabi> createState() => _PunjabiState();
}

class _PunjabiState extends State<Punjabi> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.red.shade200,
      body: Center(child: Text("Tab 3"),),);
  }
}
