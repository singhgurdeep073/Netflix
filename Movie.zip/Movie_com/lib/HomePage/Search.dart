import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';


import '../Api/Category/Category.dart';
import '../Api/Category/SubCategory.dart';
class search extends StatefulWidget {
  const search({Key? key}) : super(key: key);

  @override
  State<search> createState() => _searchState();
}

class _searchState extends State<search> {
  Future<List<Catid>> fetchData() async{
    var url=Uri.parse("http://www.paji.store/WebService1.asmx/Category?");
    final responce=await http.get(url);
    if(responce.statusCode==200){
      List listresponce=json.decode(responce.body);
      return listresponce.map((data) => Catid.FromJson(data)).toList();
    }
    else{
      throw Exception('Unexpected error occured!');
    }


  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Column(
            children:[
              SizedBox(height: 30,),
              Padding(
                padding:  EdgeInsets.only(left: 18.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text("Search",style: TextStyle(color: Colors.white,fontSize: 30),),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 8.0,left: 10,right: 10),
                child: Container(
                  height: 700,
                  width: double.infinity,

                  child: FutureBuilder<List<Catid>>(
                      future: fetchData(),
                      builder: (context,abc){
                        if(abc.hasData){
                          return
                            GridView.builder(

                                itemCount: abc.data!.length,
                                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2,mainAxisSpacing: 10,crossAxisSpacing: 10,mainAxisExtent: 140), itemBuilder: (context,index){
                              return InkWell(
                                onTap: (){
                                  Navigator.push(context,MaterialPageRoute(builder: (context){
                                    return Subcat(id:abc.data![index].id.toString());
                                  }));

                                },
                                child: Container(

                                  decoration: BoxDecoration(

                                      gradient: LinearGradient(colors: [
                                        Colors.white.withOpacity(0.2),
                                        Colors.black.withOpacity(0.2),
                                        Colors.red.withOpacity(0.2),
                                      ]),

                                      borderRadius: BorderRadius.circular(15)
                                  ),

                                  child: Column(children: [
                                    SizedBox(height: 17,),
                                    CircleAvatar(
                                      radius: 40,
                                      backgroundImage: NetworkImage(abc.data![index].img,),
                                    ),
                                    /*     Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Image.network(abc.data![index].img,height: 100,),
                                ),*/
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Text(abc.data![index].name,style: TextStyle(color: Colors.white),),
                                    )

                                  ],),
                                ),
                              );
                            });

                        }
                        else if(abc.hasError){
                          return Text(abc.error.toString());

                        }
                        return  Icon(Icons.circle_outlined);
                      }

                  ),
                ),
              ),
            ]   ),
      ),
      floatingActionButton: FloatingActionButton(

        onPressed: () {
          // Show the bottom sheet with the search bar
          showModalBottomSheet(
            backgroundColor: Colors.black87,
            context: context,

            isScrollControlled: true,
            builder: (context) {
              return Padding(
                padding: EdgeInsets.only(
                    bottom: MediaQuery.of(context).viewInsets.bottom),
                child: Container(
                  margin: EdgeInsets.all(10),
                  height: 60,
                  child:   TextFormField(

                    decoration: InputDecoration(
                      contentPadding: EdgeInsets.symmetric(vertical: 15.0),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.grey),
                        borderRadius: BorderRadius.all(Radius.circular(10.0)),
                      ),
                      filled: true,
                      fillColor: Colors.grey,
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.black),
                        borderRadius: BorderRadius.all(Radius.circular(10.0)),
                      ),
                      hintText: '   Search Here...',
                      hintStyle: TextStyle(
                          fontSize: 13.0, color: Colors.white,
                          fontWeight: FontWeight.bold
                      ),
                      suffixIcon: Icon(
                        Icons.search,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              );
            },
          );
        },
        child:Icon(Icons.search, size: 25, color: Colors.white,shadows: [BoxShadow(color: Colors.black,blurRadius: 10,)],),

        backgroundColor: Colors.red,
      ),
    );
  }
}
