import 'package:flutter/material.dart';
import 'package:flutter_signin_button/button_list.dart';
import 'package:flutter_signin_button/button_view.dart';
import 'package:url_launcher/url_launcher.dart';

class Tap extends StatefulWidget {
  const Tap({super.key});

  @override
  State<Tap> createState() => _TapState();
}

class _TapState extends State<Tap> {
  Future<void> _launchUrl() async {
    if (!await launchUrl(_url)) {
      throw Exception('Could not launch $_url');
    }
  }
  Future<void> _github() async {
    if (!await launchUrl(_githubUrl)) {
      throw Exception('Could not launch $_url');
    }
  }


  final Uri _url = Uri.parse('https://www.jiocinema.com/movies/bloody-daddy/3760812/watch');
  final Uri _githubUrl = Uri.parse('https://github.com');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SignInButton(
              Buttons.GoogleDark,
              onPressed:  _launchUrl,
            ),
            SignInButton(
              Buttons.GitHub,
              onPressed:  _github,
            )

          ],
        ),
      ),
    );
  }
}