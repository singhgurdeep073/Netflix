package com.example.movie_com

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
